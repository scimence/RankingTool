﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rankingTool
{
    class ToolDB
    {
        static string ToolConfig = AppDomain.CurrentDomain.BaseDirectory + "config.txt";

        /// <summary>
        /// 保存配置信息
        /// </summary>
        /// <param name="rankDic"></param>
        public static void Save(Dictionary<string, SearchData> rankDic)
        {
            StringBuilder sb = new StringBuilder();
            foreach(string key in rankDic.Keys)
            {
                sb.AppendLine(key);
            }
            string data = sb.ToString();

            FileProcess.SaveProcess(data, ToolConfig);
        }

        /// <summary>
        /// 载入配置信息
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, SearchData> Load()
        {
            Dictionary<string, SearchData> dic = new Dictionary<string, SearchData>();

            string data = FileProcess.fileToString(ToolConfig);
            string[] lines = data.Replace("\r\n", "\n").Split('\n');
            foreach(string line in lines)
            {
                string lineData = line.Trim();
                if(!lineData.Equals(""))
                {
                    SearchData iteam = SearchData.Parse(lineData);
                    if (iteam != null && !dic.ContainsKey(iteam.ToString()))
                    {
                        dic.Add(iteam.ToString(), iteam);
                    }
                }
            }

            return dic;
        }
    }
}
