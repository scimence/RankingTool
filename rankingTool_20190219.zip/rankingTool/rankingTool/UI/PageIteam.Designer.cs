﻿namespace rankingTool.UI
{
    partial class PageIteam
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.transLabel_Descript = new rankingTool.UI.TransLabel();
            this.transLabel_Tittle = new rankingTool.UI.TransLabel();
            this.SuspendLayout();
            // 
            // transLabel_Descript
            // 
            this.transLabel_Descript.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.transLabel_Descript.FontColor = System.Drawing.Color.Black;
            this.transLabel_Descript.LabelFont = new System.Drawing.Font("宋体", 12F);
            this.transLabel_Descript.LabelText = "TransLabel 显示内容信息显示 内容信息";
            this.transLabel_Descript.Location = new System.Drawing.Point(3, 32);
            this.transLabel_Descript.Name = "transLabel_Descript";
            this.transLabel_Descript.Size = new System.Drawing.Size(240, 19);
            this.transLabel_Descript.TabIndex = 1;
            this.transLabel_Descript.MouseEnter += new System.EventHandler(this.PageIteam_Click);
            // 
            // transLabel_Tittle
            // 
            this.transLabel_Tittle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.transLabel_Tittle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.transLabel_Tittle.FontColor = System.Drawing.Color.Blue;
            this.transLabel_Tittle.LabelFont = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Underline);
            this.transLabel_Tittle.LabelText = "TransLabel_标题";
            this.transLabel_Tittle.Location = new System.Drawing.Point(3, 5);
            this.transLabel_Tittle.Name = "transLabel_Tittle";
            this.transLabel_Tittle.Size = new System.Drawing.Size(240, 23);
            this.transLabel_Tittle.TabIndex = 0;
            this.transLabel_Tittle.Click += new System.EventHandler(this.transLabel_Tittle_Click);
            this.transLabel_Tittle.MouseEnter += new System.EventHandler(this.PageIteam_Click);
            // 
            // PageIteam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.transLabel_Descript);
            this.Controls.Add(this.transLabel_Tittle);
            this.Name = "PageIteam";
            this.Size = new System.Drawing.Size(246, 55);
            this.MouseEnter += new System.EventHandler(this.PageIteam_Click);
            this.ResumeLayout(false);

        }

        #endregion

        private TransLabel transLabel_Tittle;
        private TransLabel transLabel_Descript;
    }
}
