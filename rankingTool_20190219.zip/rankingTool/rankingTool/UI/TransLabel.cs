﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool.UI
{
    /// <summary>
    /// 此类用于实现透明的Label标签信息显示
    /// </summary>
    public partial class TransLabel : UserControl
    {
        public TransLabel()
        {
            InitializeComponent();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            //不进行背景的绘制  
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00000020; //WS_EX_TRANSPARENT  
                return cp;
            }
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            //绘制panel的背景图像  
            //if (BackgroundImage != null) e.Graphics.DrawImage(this.BackgroundImage, new Point(0, 0));

            Brush brush = new SolidBrush(fontColor);        // 设置颜色
            e.Graphics.DrawString(labelText, labelFont, brush, 0, 0); // 绘制对应颜色的label标签
        }

        private string labelText = "TransLabel";
        [Description("与控件关联的文本"), Category("自定义属性")]
        public string LabelText
        {
            get
            {
                return labelText;
            }
            set
            {
                labelText = value;
                this.Invalidate();  // 设置文本后，刷新显示
            }
        }

        private Font labelFont = new Font(new FontFamily("宋体"), 12);
        [Description("显示字体信息"), Category("自定义属性")]
        public Font LabelFont
        {
            get
            {
                return labelFont;
            }
            set
            {
                labelFont = value;
                this.Invalidate();  // 设置字体后，刷新显示
            }
        }

        private Color fontColor = Color.White;
        [Description("显示字体的颜色"), Category("自定义属性")]
        public Color FontColor
        {
            get
            {
                return fontColor;
            }
            set
            {
                fontColor = value;
                this.Invalidate();  // 设置字体后，刷新显示
            }
        }
    }
}
