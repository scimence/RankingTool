﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //PageBaidu.testSearch();
            
            ThreadTool.ThreadRun(searchLogic);  // 在新的线程中执行检索逻辑
        }

        int searchNum = 10;
        private  void searchLogic()
        {
            searchNum = Int32.Parse(textNumber.Text.Trim());
            string searchKey = textSearch.Text.Trim();                          // 待检索的关键字

            List<SearchData> list = PageBaidu.Search(searchKey, searchNum);     // 调用百度检索

            this.Invoke(new EventHandler(delegate
            {
                searchPannel_content.ShowData(list);                            // 在pannel上显示搜索结果
            }));
            
            //searchPannel_content.DataList = list;             // 设置检索列表显示内容
        }

        Dictionary<string, SearchData> rankDic = new Dictionary<string, SearchData>();
        private void searchPannel_content_ContextMenuClick(object sender, EventArgs e, string menuName, UI.PageIteam selectedIteam)
        {
            SearchData data = selectedIteam.Data();
            string key = data.ToString();

            if (menuName.Equals("添加"))
            {
                if (!rankDic.Keys.Contains(key))
                {
                    rankDic.Add(key, data);
                    ToolDB.Save(rankDic);

                    MessageBox.Show("\"" + data.tittle + "\"" + " 已添加");
                }
                else
                {
                    MessageBox.Show("\"" + data.tittle + "\"" + " 已存在!");
                }
            }
            else if (menuName.Equals("删除"))
            {
                if (rankDic.Keys.Contains(key))
                {
                    rankDic.Remove(key);
                    ToolDB.Save(rankDic);

                    MessageBox.Show("\"" + data.tittle + "\"" + " 已删除");
                }
                else MessageBox.Show("\"" + data.tittle + "\"" + " 不存在!");
            }
            else if (menuName.Equals("查看"))
            {
                MessageBox.Show(data.tittle);
            }
            else if (menuName.Equals("刷榜"))
            {
                //SearchData data = selectedIteam.Data();
                //dataX = data;           // 刷榜数据

                timer1.Enabled = true;  // 启动刷榜
            }
        }

        long count = 1;

        private void timer1_Tick(object sender, EventArgs e)
        {
            ThreadTool.ThreadRun(RankLogic);  // 在新的线程中执行刷链接逻辑
        }

        private void RankLogic()
        {
            Dictionary<string, SearchData> rankDic = ToolDB.Load();
            foreach (SearchData dataX in rankDic.Values)
            {
                RankProcess(dataX);
            }
        }

        private void RankProcess(SearchData iteam)
        {
            if (iteam == null) return;

            try
            {
                string key = iteam.key;                                     // 检索关键字
                List<SearchData> list = PageBaidu.Search(key, searchNum, iteam);   // 调用百度检索

                foreach (SearchData data in list)
                {
                    if (data.Equal(iteam))                                  // 检索到关键字
                    {
                        //new WebForm(data.link).Show();
                        WebForm.LogicShow(data.link);

                        //String dataL = WebTool.getWebData(data.link);       // 刷榜（内部打开链接）
                        count++;

                        this.Invoke(new EventHandler(delegate
                        {
                            this.Text = "rankingTool " + count + " " + data.link;
                        }));

                        break;
                    }
                }
            }
            catch (Exception ex)
            { }
        }
    }
}
