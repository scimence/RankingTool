﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            //args = new string[] { "hide" };
            args = analyseArgs(args);
            DllTool.LoadResourceDll();                // 载入依赖dll
            _Main();
        }

        static bool Hide = false;
        static string[] analyseArgs(string[] args)
        {
            List<string> list = new List<string>();
            if(args != null && args.Length > 0)
            {
                foreach(string arg in args)
                {
                    if (arg.Trim().Equals("hide")) Hide = true;
                    else list.Add(arg.Trim());
                }
            }

            return list.ToArray();
        }

        static void _Main()
        {
            SciUpdate.RunningExceptionTool.Run(call);   // 调用异常信息捕获类，进行异常信息的捕获
        }

        // 应用程序，入口逻辑
        public static void call(string[] args)
        {
            if (Hide)
            {
                Rank.Ranking();     // 
                Application.Run();  // 运行应用程序消息
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                string ToolUrl_MD5 = "https://raw.githubusercontent.com/joymeng/RankingTool/master/MD5.txt";
                string perfix_EXE = "rankingTool.exe";
                SciUpdate.UpdateTool.AutoUpdate(ToolUrl_MD5, perfix_EXE);

                Application.Run(new SearchForm());
                //Application.Run(new WebForm("https://hao.360.cn"));
            }
        }
    }
}
