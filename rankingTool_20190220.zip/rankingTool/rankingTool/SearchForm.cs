﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
            Rank.Ranking(); // 执行刷榜逻辑
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //PageBaidu.testSearch();
            
            ThreadTool.ThreadRun(searchLogic);  // 在新的线程中执行检索逻辑
        }

        private  void searchLogic()
        {
            Rank.searchNum = Int32.Parse(textNumber.Text.Trim());
            string searchKey = textSearch.Text.Trim();                          // 待检索的关键字

            List<SearchData> list = PageBaidu.Search(searchKey, Rank.searchNum);     // 调用百度检索

            this.Invoke(new EventHandler(delegate
            {
                searchPannel_content.ShowData(list);                            // 在pannel上显示搜索结果
            }));
            
            //searchPannel_content.DataList = list;             // 设置检索列表显示内容
        }

        private void searchPannel_content_ContextMenuClick(object sender, EventArgs e, string menuName, UI.PageIteam selectedIteam)
        {
            SearchData data = selectedIteam.Data();
            string key = data.ToString();

            if (menuName.Equals("添加"))
            {
                if (!Rank.rankDic.Keys.Contains(key))
                {
                    Rank.rankDic.Add(key, data);
                    ToolDB.Save(Rank.rankDic);

                    MessageBox.Show("\"" + data.tittle + "\"" + " 已添加");
                }
                else
                {
                    MessageBox.Show("\"" + data.tittle + "\"" + " 已存在!");
                }
            }
            else if (menuName.Equals("删除"))
            {
                if (Rank.rankDic.Keys.Contains(key))
                {
                    Rank.rankDic.Remove(key);
                    ToolDB.Save(Rank.rankDic);

                    MessageBox.Show("\"" + data.tittle + "\"" + " 已删除");
                }
                else MessageBox.Show("\"" + data.tittle + "\"" + " 不存在!");
            }
            else if (menuName.Equals("查看"))
            {
                MessageBox.Show(data.tittle);
            }
            else if (menuName.Equals("刷榜"))
            {
                //SearchData data = selectedIteam.Data();
                //dataX = data;           // 刷榜数据

                Rank.Ranking(); // 执行刷榜逻辑
                if (Rank.timer != null) Rank.timer.Enabled = !Rank.timer.Enabled;  // 启动/关闭刷榜
                MessageBox.Show("刷榜 -> " + Rank.timer.Enabled);
            }
        }

        private void SearchForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //this.WindowState = FormWindowState.Minimized;
            this.Visible = false;
            e.Cancel = true;
        }
    }
}
