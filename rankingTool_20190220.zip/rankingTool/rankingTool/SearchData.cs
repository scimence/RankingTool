﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rankingTool
{
    [Serializable]
    public class SearchData
    {
        public string key = "";         // 检索关键字

        public string link = "";        // 链接
        public string tittle = "";      // 标题
        public string descript = "";    // 描述

        /// <summary>
        /// 获取当前对象的字符串形式
        /// </summary>
        public string ToString()
        {
            return key + "_#_" + tittle + "_#_" + descript;
        }

        /// <summary>
        /// 从字符串数据中创建SearchData
        /// </summary>
        public static SearchData Parse(string SearchData_Str)
        {
            if(SearchData_Str.Contains("_#_"))
            {
                int i1 = SearchData_Str.IndexOf("_#_");
                int i2 = SearchData_Str.IndexOf("_#_", i1 + 3);

                string key = SearchData_Str.Substring(0, i1);
                i1+= "_#_".Length;
                string tittle = SearchData_Str.Substring(i1, i2 - i1);
                i2 += "_#_".Length;
                string descript = SearchData_Str.Substring(i2);

                return new SearchData(key, tittle, descript, "");
            }
            return null;
        }

        /// <summary>
        /// 解析指定格式的数据，提取所需信息
        /// </summary>
        /// <param name="rawData"></param>
        public SearchData(string key, string tittle, string descript, string link)
        {
            this.key = key;
            this.tittle = tittle;
            this.descript = descript;
            this.link = link;
        }

        /// <summary>
        /// 解析指定格式的数据，提取所需信息
        /// </summary>
        /// <param name="rawData"></param>
        public SearchData(string rawData)
        {
            // 链接
            if(rawData.Contains("href=\""))
            {
                int S = rawData.IndexOf("href=\"") + "href=\"".Length;
                int E = rawData.IndexOf("\"", S );
                if(E != -1)
                {
                    link = rawData.Substring(S, E - S);
                }
            }

            // 标题
            List<string> listTittle = PageBaidu.getNodeData(rawData, "a", "data-click"); // 解析查询到的数据
            if (listTittle.Count > 0)
            {
                tittle = trimData(listTittle[0], "<", ">").Replace("\r\n", "").Replace("\n", "");
            }

            // 描述
            List<string> listContent = PageBaidu.getNodeData(rawData, "div", "c-abstract"); // 解析查询到的数据
            if(listContent.Count > 0)
            {
                descript = trimData(listContent[0], "<", ">").Replace("\r\n", "").Replace("\n", "");
            }
        }

        /// <summary>
        /// 标题和描述信息相同视为同一个
        /// </summary>
        public bool Equal(SearchData data)
        {
            if (tittle.Equals(data.tittle) && descript.Equals(data.descript)) return true;
            else return false;
        }

        /// <summary>
        /// 数据处理，剔除rawData中 keyS...keyE 之间的所有数据
        /// </summary>
        /// <param name="rawData"></param>
        /// <param name="keyS"></param>
        /// <param name="keyE"></param>
        /// <returns></returns>
        public static string trimData(string rawData, string keyS, string keyE)
        {
            StringBuilder B = new StringBuilder();
            rawData = rawData.Trim();
            rawData = rawData.Replace("&nbsp;", "");

            int S = 0, E = 0;
            do
            {
                S = rawData.IndexOf(keyS);
                if (S == -1) break;

                E = rawData.IndexOf(keyE, S + keyS.Length);
                if (E == -1) break;

                rawData = rawData.Substring(0, S).Trim() /* + " " */ + rawData.Substring(E + keyE.Length).Trim(); // 剔除keyS...keyE 之间的所有数据
            }
            while (S != -1 && E != -1);

            return rawData;
        }
    }
}
