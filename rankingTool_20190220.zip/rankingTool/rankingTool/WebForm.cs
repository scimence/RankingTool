﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool
{
    public partial class WebForm : Form
    {
        public WebForm()
        {
            InitializeComponent();
        }

        public WebForm(string url)
        {
            InitializeComponent();
            setUrl(url);
        }

        public void setUrl(string url)
        {
            webBrowser1.Url = new Uri(url);
        }

        static WebForm I;
        /// <summary>
        /// 逻辑加载页面
        /// </summary>
        public static void Show(string url)
        {
            if (I == null)
            {
                I = new WebForm();
                //I.Show();
            }
            I.setUrl(url);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            setUrl("https://www.baidu.com/");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            setUrl("https://fanyi.baidu.com/");
        }

        //-------

        private static WebBrowser borwser;
        public static void LogicShow(string url = null)
        {
            if (borwser == null)
            {
                borwser = new WebBrowser();
                //I.Show();
            }
            if (url != null && !url.Equals(""))
            {
                borwser.Url = new Uri(url);
                string tmp = url;
            }
        }
    }
}
