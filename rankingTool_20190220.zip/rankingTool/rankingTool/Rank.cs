﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool
{
    public class Rank
    {
        public static Dictionary<string, SearchData> rankDic = new Dictionary<string, SearchData>();
        public static int searchNum = 10;
        public static Timer timer;

        public static void Ranking()
        {
            if (timer == null)
            {
                ShowUrlInLogic();           // 创建Browser

                timer = new Timer();
                timer.Interval = 10000;
                timer.Tick += timer_Tick;
                timer.Enabled = true;
            }
        }

        private static void timer_Tick(object sender, EventArgs e)
        {
            ThreadTool.ThreadRun(RankLogic);  // 在新的线程中执行刷链接逻辑
        }

        private static void RankLogic()
        {
            rankDic = ToolDB.Load();
            foreach (SearchData dataX in rankDic.Values)
            {
                RankProcess(dataX);
            }
        }

        private static void RankProcess(SearchData iteam)
        {
            if (iteam == null) return;

            try
            {
                string key = iteam.key;                                     // 检索关键字
                List<SearchData> list = PageBaidu.Search(key, searchNum, iteam);   // 调用百度检索

                foreach (SearchData data in list)
                {
                    if (data.Equal(iteam))                                  // 检索到关键字
                    {
                        //new WebForm(data.link).Show();
                        ShowUrlInLogic(data.link);  // 在browser中载入url

                        //String dataL = WebTool.getWebData(data.link);     // 刷榜（内部打开链接）

                        //this.Invoke(new EventHandler(delegate
                        //{
                        //    this.Text = "rankingTool " + count + " " + data.link;
                        //}));

                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                string data = ex.ToString();
            }
        }


        //-------

        private static WebBrowser borwser;
        public static void ShowUrlInLogic(string url = null)
        {
            if (borwser == null)
            {
                borwser = new WebBrowser();
                borwser.ScriptErrorsSuppressed = true;
            }
            if (url != null && !url.Equals(""))
            {
                borwser.Url = new Uri(url);
                string tmp = url;
            }
        }
    }
}
