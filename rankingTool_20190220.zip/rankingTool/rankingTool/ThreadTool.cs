﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool
{
    public class ThreadTool
    {
        /// <summary>
        /// 定义委托接口处理函数，用于实时处理cmd输出信息，或传递功能逻辑变量
        /// </summary>
        public delegate void Method();

        /// <summary>
        /// 在新的线程中执行method逻辑
        /// </summary>
        public static void ThreadRun(Method method, Form form = null, Button button = null, String Text = "执行中", bool useThread = true)
        {
            if (useThread)
            {
                Thread thread = new Thread(delegate()
                {
                    // 允许不同线程间的调用
                    Control.CheckForIllegalCrossThreadCalls = false;

                    // 设置按钮和界面按钮不可用
                    String text = "";
                    if (form != null) form.ControlBox = false;

                    if (button != null)
                    {
                        text = button.Text;
                        button.Text = Text;
                        button.Enabled = false;
                    }

                    // 执行method逻辑
                    if (method != null) method();


                    if (button != null)
                    {
                        button.Text = text;
                        button.Enabled = true;
                    }
                    if (form != null) form.ControlBox = true;
                });

                thread.Priority = ThreadPriority.AboveNormal;           // 设置子线程优先级
                Thread.CurrentThread.Priority = ThreadPriority.Highest; // 设置当前线程为最高优先级
                thread.Start();
            }
            else
            {
                // 设置按钮和界面按钮不可用
                String text = "";
                if (form != null) form.ControlBox = false;

                if (button != null)
                {
                    text = button.Text;
                    button.Text = Text;
                    button.Enabled = false;
                }

                // 执行method逻辑
                if (method != null) method();


                if (button != null)
                {
                    button.Text = text;
                    button.Enabled = true;
                }
                if (form != null) form.ControlBox = true;
            }
        }

    }
}
