﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool.UI
{
    // 此控件为透明控件，带有背景图像属性，可响应点击处理逻辑
    public partial class TransPictureBox : UserControl
    {
        public TransPictureBox()
        {
            InitializeComponent();
            //AutoSize = true;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            //不进行背景的绘制  
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00000020; //WS_EX_TRANSPARENT  
                return cp;
            }
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            //绘制panel的背景图像  
            if (BackgroundImage != null) e.Graphics.DrawImage(this.BackgroundImage, new Point(0, 0));
        }

        //private bool autoSize = true;
        //[Description("是否根据背景，自动设置控件大小"), Category("自定义属性")]
        //public bool AutoSize
        //{
        //    get
        //    {
        //        return autoSize;
        //    }
        //    set
        //    {
        //        autoSize = value;
        //        if (BackgroundImage != null)
        //        {
        //            this.Width = this.BackgroundImage.Width;
        //            this.Height = this.BackgroundImage.Height;
        //        }
        //    }
        //}

        public delegate void click_Handle(object sender, EventArgs e);
        [Description("点击控件处理逻辑"), Category("自定义事件")]
        public event click_Handle Clicked;

        // 鼠标点击控件点击时，调用此逻辑
        private void TransparentPanel_Click(object sender, EventArgs e)
        {
            if (Clicked != null)
            {
                Clicked(this, new EventArgs());
            }
        }
    }
}
