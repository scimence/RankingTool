﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //PageBaidu.testSearch();

            string key = textSearch.Text.Trim();                // 待检索的关键字
            List<SearchData> list = PageBaidu.Search(key, 10);  // 调用百度检索
            searchPannel_content.ShowData(list);                // 在pannel上显示搜索结果
            //searchPannel_content.DataList = list;               // 设置检索列表显示内容
        }

        private void searchPannel_content_ContextMenuClick(object sender, EventArgs e, string menuName, UI.PageIteam selectedIteam)
        {
            if (menuName.Equals("查看"))
            {
                MessageBox.Show(selectedIteam.TittleText);
            }
            else if (menuName.Equals("刷榜"))
            {
                SearchData data = new SearchData(selectedIteam.Key, selectedIteam.TittleText, selectedIteam.DescriptText, selectedIteam.Link);
                
                dataX = data;           // 刷榜数据
                timer1.Enabled = true;  // 启动刷榜
            }
        }

        long count = 1;
        SearchData dataX;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (dataX == null) return;

            string key = dataX.key;                                     // 检索关键字
            List<SearchData> list = PageBaidu.Search(key, 50, dataX);   // 调用百度检索

            foreach (SearchData data in list)
            {
                if (data.Equal(dataX))                                  // 检索到关键字
                {
                    String dataL = WebTool.getWebData(data.link);       // 刷榜（内部打开链接）
                    count++;
                    this.Text = "rankingTool " + count + " " + data.link;

                    break;
                }
            }
        }

    }
}
