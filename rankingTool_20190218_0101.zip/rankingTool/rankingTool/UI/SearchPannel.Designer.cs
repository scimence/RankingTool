﻿namespace rankingTool.UI
{
    partial class SearchPannel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.flowLayoutPanel_Iteams = new System.Windows.Forms.FlowLayoutPanel();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.查看ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刷榜ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel_Iteams
            // 
            this.flowLayoutPanel_Iteams.AutoScroll = true;
            this.flowLayoutPanel_Iteams.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel_Iteams.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel_Iteams.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel_Iteams.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel_Iteams.Name = "flowLayoutPanel_Iteams";
            this.flowLayoutPanel_Iteams.Size = new System.Drawing.Size(253, 150);
            this.flowLayoutPanel_Iteams.TabIndex = 2;
            this.flowLayoutPanel_Iteams.WrapContents = false;
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查看ToolStripMenuItem,
            this.刷榜ToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(153, 70);
            // 
            // 查看ToolStripMenuItem
            // 
            this.查看ToolStripMenuItem.Name = "查看ToolStripMenuItem";
            this.查看ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.查看ToolStripMenuItem.Text = "查看";
            this.查看ToolStripMenuItem.Click += new System.EventHandler(this.查看ToolStripMenuItem_Click);
            // 
            // 刷榜ToolStripMenuItem
            // 
            this.刷榜ToolStripMenuItem.Name = "刷榜ToolStripMenuItem";
            this.刷榜ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.刷榜ToolStripMenuItem.Text = "刷榜";
            this.刷榜ToolStripMenuItem.Click += new System.EventHandler(this.刷榜ToolStripMenuItem_Click);
            // 
            // SearchPannel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.flowLayoutPanel_Iteams);
            this.Name = "SearchPannel";
            this.Size = new System.Drawing.Size(253, 150);
            this.Resize += new System.EventHandler(this.SearchPannel_Resize);
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_Iteams;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem 查看ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 刷榜ToolStripMenuItem;


    }
}
