﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool.UI
{
    public partial class SearchPannel : UserControl
    {
        public SearchPannel()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 在当前pannel上显示数据信息
        /// </summary>
        public void ShowData(List<SearchData> dataList)
        {
            List<PageIteam> pageIteams = new List<PageIteam>();
            foreach (SearchData data in dataList)
            {
                PageIteam iteam = new PageIteam(data.tittle, data.descript, data.link);
                iteam.Key = data.key;

                pageIteams.Add(iteam);
            }

            SetIteams(pageIteams);
        }


        private List<PageIteam> pageIteams = new List<PageIteam>();
        public void SetIteams(List<PageIteam> iteams)
        {
            flowLayoutPanel_Iteams.Controls.Clear();        // 清空原有子控件

            foreach (PageIteam iteam in iteams)
            {
                pageIteams.Add(iteam);

                iteam.ContextMenuStrip = contextMenuStrip;
                iteam.IteamClick_M += new PageIteam.Click_Handle(this.Iteam_Click);       // 为控件添加选中处理逻辑
                
                iteam.Width = this.Width-30;                   // 修改添加的控件宽度为当前pannel宽度
                flowLayoutPanel_Iteams.Controls.Add(iteam); // 添加到pannel
            }
            this.Invalidate();                              // 刷新当前控件的显示
        }

        public List<PageIteam> GetIteam()
        {
            return pageIteams;
        }

        /// <summary>
        /// 添加新的iteam到pannel
        /// </summary>
        public void AddIteam(PageIteam iteam)
        {
            if (!pageIteams.Contains(iteam))
            {
                pageIteams.Add(iteam);
               
                iteam.ContextMenuStrip = contextMenuStrip;
                iteam.IteamClick_M += new PageIteam.Click_Handle(this.Iteam_Click);       // 为控件添加选中处理逻辑
                
                iteam.Width = this.Width - 30;
                flowLayoutPanel_Iteams.Controls.Add(iteam);

                this.Invalidate();
            }
        }

        /// <summary>
        /// 从pannel上移除iteam
        /// </summary>
        public void RemoveIteam(PageIteam iteam)
        {
            if (pageIteams.Contains(iteam))
            {
                pageIteams.Remove(iteam);
                flowLayoutPanel_Iteams.Controls.Remove(iteam);

                this.Invalidate();
            }
        }

        /// <summary>
        /// 清空所有iteam
        /// </summary>
        public void ClearIteams()
        {
            flowLayoutPanel_Iteams.Controls.Clear();        // 清空原有子控件
            pageIteams.Clear();
            this.Invalidate();
        }

        // 尺寸变动，修改子控件显示尺寸
        private void SearchPannel_Resize(object sender, EventArgs e)
        {
            foreach (PageIteam iteam in pageIteams)
            {
                iteam.Width = this.Width - 30;                   // 修改添加的控件宽度为当前pannel宽度
            }
            this.Invalidate();                              // 刷新当前控件的显示
        }

        //-------

        private PageIteam selectedIteam;
        [Description("鼠标点击时，选中的PageIteam"), Category("自定义属性")]
        public PageIteam SelectedIteam
        {
            get
            {
                return selectedIteam;
            }
            set
            {
                selectedIteam = value;
            }
        }

        public delegate void contextMenu_Handle(object sender, EventArgs e, String menuName, PageIteam selectedIteam);
        [Description("当前控件的右键弹出菜单响应处理逻辑"), Category("自定义事件")]
        public event contextMenu_Handle ContextMenuClick;

        private void PageIteams_ContextMenuClick(String menuName)
        {
            if (ContextMenuClick != null) ContextMenuClick(this, new EventArgs(), menuName, selectedIteam);
        }

        private void 查看ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PageIteams_ContextMenuClick("查看");
        }

        private void 刷榜ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PageIteams_ContextMenuClick("刷榜");
        }

        // 按钮点击时，调用此逻辑
        private void Iteam_Click(object sender, EventArgs e)
        {
            selectedIteam = sender as PageIteam;
        }

    }
}
