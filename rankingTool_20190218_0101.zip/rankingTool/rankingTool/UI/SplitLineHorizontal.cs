﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool.UI
{
    // 此类用于实现绘制一条水平分隔线， 按F5运行一次，再拖动当前控件到Form窗体即可看到
    // 自定义属性：DrawColor和自定义事件This_Selected
    public partial class SplitLineHorizontal : UserControl
    {
        public SplitLineHorizontal()
        {
            InitializeComponent();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            //不进行背景的绘制
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00000020; //WS_EX_TRANSPARENT
                return cp;
            }
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            Pen pen = new Pen(drawColor);
            pen.Width = 2;

            // 绘制一条水平分割线
            e.Graphics.DrawLine(pen, new Point(5, 5), new Point(this.Width - 5, 5));

            ////绘制panel的背景图像
            //if (BackgroundImage != null) e.Graphics.DrawImage(this.BackgroundImage, new Point(0, 0));
        }



        private Color drawColor = Color.Black;  // 存储颜色值的内部变量
        [Description("修改此值，可修改分割线的颜色"), Category("自定义属性")]
        public Color DrawColor                  // 控件的自定义属性值
        {
            get
            {
                return drawColor;
            }
            set
            {
                drawColor = value;

                // 此处修改，为自定义属性变动时，执行的操作
                this.Invalidate();  // 此处当颜色值属性变动时，使用新的颜色，使自定义控件重绘
            }
        }


        public delegate void select_Handle(object sender, EventArgs e, string orther);  // 自定义事件的参数类型
        [Description("当点击控件时发生，调用选中当前控件逻辑"), Category("自定义事件")]
        public event select_Handle This_Selected;                                       // 自定义事件名,

        // 在当前控件的某个默认事件中调用自定义事件，此处使用默认的Click事件时，调用自定义的选中事件This_Selected
        private void SplitLineHorizontal_Click(object sender, EventArgs e)
        {
            //DrawColor = Color.Red;      // 定义选中控件时，显示为红色
            if (This_Selected != null) This_Selected(this, new EventArgs(), "其它参数");//调用自定义事件
        }
    }
}
