﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rankingTool.UI
{
    public partial class PageIteam : UserControl
    {
        public PageIteam()
        {
            InitializeComponent();
        }

        public PageIteam(string tittle, string descript, string link)
        {
            InitializeComponent();

            this.TittleText = tittle;
            this.DescriptText = descript;
            this.Link = link;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            //不进行背景的绘制
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00000020; //WS_EX_TRANSPARENT
                return cp;
            }
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            ////绘制panel的背景图像
            //if (BackgroundImage != null) e.Graphics.DrawImage(this.BackgroundImage, new Point(0, 0));
            //e.Graphics.DrawString(

            // 选中控件时，绘制背景色
            //if(selected)
            //{
            //    Brush brush = new SolidBrush(this.BackColor);
            //    e.Graphics.FillRectangle(brush, 0, 0, this.Width, this.Height);
            //}
        }

        public String Key = "";

        private String tittleText = "TransLabel_标题";
        [Description("标题信息"), Category("自定义属性")]
        public String TittleText
        {
            get
            {
                return tittleText;
            }
            set
            {
                tittleText = value;
                transLabel_Tittle.LabelText = tittleText;
            }
        }

        private String descriptText = "TransLabel 显示内容描述信息 显示内容信息";
        [Description("内容描述信息"), Category("自定义属性")]
        public String DescriptText
        {
            get
            {
                return descriptText;
            }
            set
            {
                descriptText = value;
                transLabel_Descript.LabelText = descriptText;
            }
        }

        private String link = "http://www.baidu.com";
        [Description("链接地址信息"), Category("自定义属性")]
        public String Link
        {
            get
            {
                return link;
            }
            set
            {
                link = value;
            }
        }

        public delegate void tittleClick_Handle(object sender, EventArgs e);
        [Description("当点击标题时发生，调用当前控件逻辑"), Category("自定义事件")]
        public event tittleClick_Handle TittleClick_M;

        private void transLabel_Tittle_Click(object sender, EventArgs e)
        {
            PageIteam_Click(null, e);

            if (TittleClick_M != null) TittleClick_M(this, e);
            else OpenLink();
        }

        /// <summary>
        /// 在浏览器中打开链接地址
        /// </summary>
        public void OpenLink()
        {
            if(link != null && !link.Equals(""))
                System.Diagnostics.Process.Start(link);
        }


        public delegate void Click_Handle(object sender, EventArgs e);
        [Description("当点击PageIteam时发生，调用当前控件逻辑"), Category("自定义事件")]
        public event Click_Handle IteamClick_M;

        private void PageIteam_Click(object sender, EventArgs e)
        {
            if (IteamClick_M != null) IteamClick_M(this, e);
        }


    }
}
