﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rankingTool
{
    /// <summary>
    /// 调用百度搜索获取搜索结果：
    /// List<SearchData> list = Search("360压缩", 10);
    /// </summary>
    public class PageBaidu
    {
        /// <summary>
        /// 检索测试 
        /// </summary>
        public static void testSearch()
        {
            //List<SearchData> list = Search("easyIcon软件", 23);
            List<SearchData> list = Search("图标", 10);

            string tittle1 = list[0].tittle;
            string link = list[0].link;
        }

        #region 搜索数据

        /// <summary>
        /// 调用百度搜索，key（检索关键字），count（查询前count个结果）
        /// </summary>
        public static List<SearchData> Search(String key, int count = 10, SearchData sdata = null)
        {
            List<SearchData> list = new List<SearchData>();

            List<string> listStr = SearchStr(key, count);
            for (int i = 0; i < count && i<listStr.Count; i++ )
            {
                string iteamData = listStr[i];
                SearchData data = new SearchData(iteamData);
                data.key = key;

                list.Add(data);

                if (sdata != null && sdata.Equal(data)) break;  //检索到目标值则停止检索
            }

            return list;
        }

        /// <summary>
        /// 调用百度搜索
        /// </summary>
        /// <param name="key">检索关键字</param>
        /// <param name="count">查询count个结果</param>
        public static List<string> SearchStr(String key, int count = 10)
        {
            List<string> list = new List<string>();

            int page = 0;
            while (page < count)
            {
                String data = getPageData(key, page).Replace("\r\n", "");       // 搜索
                List<string> listTmp = getNodeData(data, "div", "c-container"); // 解析查询到的数据

                list.AddRange(listTmp);
                page += 10;
            }

            return list;
        }

        ///// <summary>
        ///// 检索测试
        ///// </summary>
        //public static void testSearch1()
        //{
        //    String data = getPageData("easyIcon软件").Replace("\r\n", "");
        //    //String data = getPageData("baidu");
        //    List<string> list = getNodeData(data, "div", "c-container");
        //    //getIteamData(list[0]);
        //}

        /// <summary>
        /// 调用百度检索指定的（关键字、第x页）
        /// </summary>
        /// <param name="key">搜索的关键字</param>
        /// <param name="page">关键字检索结果，第page页</param>
        /// <returns></returns>
        public static String getPageData(String key, int page=0)
        {
            String data = "";

            String wd = key.Trim();
            String pn = page + "";

            // 百度检索：http://www.baidu.com/s?wd=天气&pn=20
            String url = "http://www.baidu.com/s?wd=" + wd + "&pn=" + pn;
            data = WebTool.getWebData(url);

            return data;
        }

        #endregion


        #region 解析页面数据信息

        /// <summary>
        /// 解析pageData上的数据项
        /// </summary>
        /// <param name="data">待解析的数据</param>
        /// <param name="nodeName">节点名称 如 div</param>
        /// <param name="attrKey">节点属性值关键字</param>
        /// <returns></returns>
        public static List<string> getNodeData(string data, string nodeName, string attrKey)
        {
            string nodeS = "<" + nodeName + " ";
            string nodeE = "</"+ nodeName + ">";

            List<string> list = new List<string>();

            int index = 0;
            while(index != -1 && index < data.Length)
            {
                int start = data.IndexOf(nodeS, index);                 // 从index索引处开始，获取<nodeName 
                if(start == -1) break;

                int startE = data.IndexOf(">", start + nodeS.Length);   // ...>
                if (startE == -1) break;
                int startE0 = startE;

                String nodeAttrStr = data.Substring(start + nodeS.Length, startE - (start + nodeS.Length));
                if (!nodeAttrStr.Contains(attrKey))
                {
                    index = startE + 1;
                    continue;
                }

                int end = 0;
                while (end != -1 && end < data.Length)
                {
                    end = data.IndexOf(nodeE, startE);              // 获取</nodeName>
                    if (end == -1) break;

                    string content = data.Substring(startE0 + 1, end - (startE0 + 1)).Trim();  // 获取节点内部数据
                    int startC = getCount(content, nodeS); // <nodeName 节点数目
                    int endC = getCount(content, nodeE);   // </nodeName> 节点数目

                    if (startC == endC)
                    {
                        list.Add(content);              // 记录节点数据
                        index = end + nodeE.Length;     // 移动至检测末尾处
                        break;
                    }
                    else
                    {
                        startE = end + nodeE.Length;    // S、E标记不匹配，检索下一个位置
                    }
                }
            }

            return list;
        }

        /// <summary>
        /// 统计data中subStr数目
        /// </summary>
        /// <param name="data"></param>
        /// <param name="subStr"></param>
        /// <returns></returns>
        public static int getCount(string data, string subStr)
        {
            int count = 0;

            int index = 0;
            while (index != -1 && index < data.Length)
            {
                index = data.IndexOf(subStr, index);
                if (index != -1)
                {
                    count++;
                    index = index + subStr.Length;
                }
            }

            return count;
        }

        #endregion


    }

}
